﻿using System;
using System.Collections.Generic;
using System.Linq;
using JsonData;

namespace ConsoleApplication
{
    public class Program
    {
        public static void Main(string[] args)
        {
            //Collections to work with
            List<Artist> Artists = MusicStore.GetData().AllArtists;
            List<Group> Groups = MusicStore.GetData().AllGroups;

            //========================================================
            //Solve all of the prompts below using various LINQ queries
            //========================================================

            //There is only one artist in this collection from Mount Vernon, what is their name and age?
            IEnumerable<Artist> justMount = Artists.Where(ho => ho.Hometown == "Mount Vernon");

            //Who is the youngest artist in our collection of artists?
            IEnumerable<Artist> youngest = Artists.OrderBy(p => p.Age);
            Artist firstOne = youngest.FirstOrDefault();


            //Display all artists with 'William' somewhere in their real name
            IEnumerable<Artist> willname = Artists.Where(prod => prod.RealName.Contains("William"));

            // Display all groups with names less than 8 characters in length.
            IEnumerable<Group> eightname = Groups.Where(ho => ho.GroupName.Length < 8);

            //Display the 3 oldest artists from Atlanta.
            IEnumerable<Artist> threepeople = Artists.OrderByDescending(p => p.Age).Where(p => p.Hometown == "Atlanta").Take(3);

            //(Optional) Display the Group Name of all groups that have members that are not from New York City
            IEnumerable<Group> grnewyork = Groups.Where(ho => ho.Members.Count > 0 && ho.Members.Hometown != "New York City");

            //(Optional) Display the artist names of all members of the group 'Wu-Tang Clan'
            foreach(var x in justMount){
            Console.WriteLine($"Real Name: {x.RealName} and Age: {x.Age}");
            }
	        
            Console.WriteLine($"Artist Name: {firstOne.ArtistName}, Real Name: {firstOne.RealName}, Age Youngest: {firstOne.Age}, Home Town: {firstOne.Hometown}");
            
            foreach(var y in willname){
            Console.WriteLine($"Real Name will: {y.RealName} and Age: {y.Age}");
            }

            foreach(var z in eightname){
            Console.WriteLine($"Group Name: {z.GroupName}");
            }

            foreach(var z in threepeople){
            Console.WriteLine($"Atlanta People Name: {z.RealName}");
            }
            
        }
    }
}
