using System;

namespace QuotingDojo.Models
{
    public class MyModel
    {
       
    }
}